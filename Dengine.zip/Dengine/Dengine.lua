local dengine = {}
oldtime = os.clock()
v_time = false

function dengine.draw(image)
  for img in io.lines(image) do
    print(img)
  end
end

function dengine.logo()
  dengine.draw("Dengine/dengine_logo.txt")
end

function dengine.timer(time)
  repeat
    if os.clock() > oldtime + time then
      os.execute("clear")
      v_time = true
    end  
  until v_time == true
  if v_time == true then
    oldtime = os.clock()
    v_time = false
  end
end  

function dengine.crash(word)
  repeat
    print(word)
  until false
end

function dengine.load(scene)
  os.execute("clear")
  dofile(scene)
end

function dengine.frame(time, img)
  dengine.draw(img)
  dengine.timer(time)
end  

return dengine
